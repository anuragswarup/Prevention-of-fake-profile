/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Watermark;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Mahesh
 */
public class Allow extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
          PrintWriter out = response.getWriter();
      HttpSession session=request.getSession();
       String uname=(String)session.getAttribute("uname");      
        String macadd=(String)session.getAttribute("macaddress");
          String imgtype=(String)session.getAttribute("imgtype");
          String com=(String)session.getAttribute("com");
           String fname=(String)session.getAttribute("fname");
          String fid=(String)session.getAttribute("fid");
            File destImageFile=null;
       
 
        try {
           
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/watermark", "root", "root");
            Statement st = con.createStatement();
            String allow="update register set Permit='Allow' where  Macaddress='"+macadd+"'";
            st.executeUpdate(allow);
           File sourceImageFile = new File("D:\\files\\" + fname);
            switch (imgtype) {
                case "Posts":
                    destImageFile = new File("C:\\Users\\prici\\Documents\\NetBeansProjects\\FP(DWT&DCT)\\web\\Images\\Posts\\" + fid + "_pro" + fname);
                    break;
                case "Profile":
                    destImageFile = new File("C:\\Users\\prici\\Documents\\NetBeansProjects\\FP(DWT&DCT)\\web\\Images\\Posts\\" + fid + "_" + fname);
                    break;
            }
           BufferedImage sourceImage = ImageIO.read(sourceImageFile);
                Graphics2D g2d = (Graphics2D) sourceImage.getGraphics();

                // initializes necessary graphic properties
                AlphaComposite alphaChannel = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.1f);
                g2d.setComposite(alphaChannel);
                g2d.setColor(Color.BLUE);
                g2d.setFont(new Font("Arial", Font.BOLD, 64));
                FontMetrics fontMetrics = g2d.getFontMetrics();
                Rectangle2D rect = fontMetrics.getStringBounds(uname, g2d);

                // calculates the coordinate where the String is painted
                int centerX = (sourceImage.getWidth() - (int) rect.getWidth()) / 2;
                int centerY = sourceImage.getHeight() / 2;

                // paints the textual watermark
                g2d.drawString(uname, centerX, centerY);

                ImageIO.write(sourceImage, "png", destImageFile);
                g2d.dispose();

                if(imgtype.equals("Profile")){
                String sql = "update  profileimages set Filename='" + fname + "', Storedname='"+ fid+ "_pro" +fname+"' where Fileid='" + fid +"'";
                st.executeUpdate(sql);
                String alw="update dupimages set status='Allow' where Macaddress='"+macadd+"'";
             st.executeUpdate(alw);
                }
                else 
                    if(imgtype.equals("Posts")){
                        String sql = "insert into postedimages values ('" + fid + "','" + fname + "','"+ fid+ "_" +fname+"','" + com + "')";
                st.executeUpdate(sql);
                String alw="update dupimages set status='Allow' where Macaddress='"+macadd+"'";
             st.executeUpdate(alw);
                    }
                out.println("<script>");
                out.println("alert('File uploaded successfully');");
                out.println("location='Userpage.jsp'");
                out.println("</script>");

            }
         catch (IOException ex) {
            System.err.println(ex);
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Allow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Allow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Allow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Allow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
