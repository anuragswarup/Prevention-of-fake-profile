/*
SQLyog Community Edition- MySQL GUI v7.02 
MySQL - 5.1.59-community : Database - watermark
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`watermark` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `watermark`;

/*Table structure for table `dupimages` */

DROP TABLE IF EXISTS `dupimages`;

CREATE TABLE `dupimages` (
  `Fileid` varchar(40) DEFAULT NULL,
  `Filename` varchar(100) DEFAULT NULL,
  `OldFileid` varchar(30) DEFAULT NULL,
  `Comment` varchar(300) DEFAULT NULL,
  `Imagetype` varchar(200) DEFAULT NULL,
  `Macaddress` varchar(30) DEFAULT NULL,
  `status` varchar(202) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dupimages` */

LOCK TABLES `dupimages` WRITE;

insert  into `dupimages`(`Fileid`,`Filename`,`OldFileid`,`Comment`,`Imagetype`,`Macaddress`,`status`) values ('clm','Cr.png','clm','cr7','Posts','B8-EE-65-D4-81-C4','Block'),('nithya','Cr.png','clm','tyui','Posts','B8-EE-65-D4-81-C4','Block'),('kahi','bbBlue-eyes-baby-sweety-babies-8885647-1920-1440.jpg','kahi','','Profile','B8-EE-65-D4-81-C4','Waiting '),('ramesh','guide.jpg','','','Posts','30-52-CB-6A-F7-9D','Allow'),('ramesh','pinterest.jpg','','gycxzc','Posts','30-52-CB-6A-F7-9D','Allow'),('ramesh','guide.jpg','','','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','pinterest.jpg','ramesh','','Profile','30-52-CB-6A-F7-9D','Allow'),('suresh','images (2).jpg','suresh','efgdsg','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','pinterest.jpg','suresh','dytduy','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','suresh_CKT 1.jpg','','sdsdsd','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','suresh_cecil-AP463227356214-1000x400.jpg','suresh','dsdasdsds','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','suresh_cecil-AP463227356214-1000x400.jpg','','bhuiguii','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','suresh_cecil-AP463227356214-1000x400.jpg','suresh','sdssdsfsff','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','suresh_images.jpg','suresh','uyuyyudsd','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','suresh_images.jpg','suresh','uiiguguiids','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','gau.jpg','suresh','hhiugyud','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','cecil-AP463227356214-1000x400.jpg','suresh','uyfyuu','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','suresh_ss.jpg','suresh','dfdfdf','Posts','30-52-CB-6A-F7-9D','Allow'),('suresh','suresh_cecil-AP463227356214-1000x400.jpg','suresh','','Profile','30-52-CB-6A-F7-9D','Allow');

UNLOCK TABLES;

/*Table structure for table `postedimages` */

DROP TABLE IF EXISTS `postedimages`;

CREATE TABLE `postedimages` (
  `Fileid` varchar(20) DEFAULT NULL,
  `Filename` varchar(303) DEFAULT NULL,
  `Storedname` varchar(303) DEFAULT NULL,
  `Comment` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `postedimages` */

LOCK TABLES `postedimages` WRITE;

insert  into `postedimages`(`Fileid`,`Filename`,`Storedname`,`Comment`) values ('nithya','204918_12167533.jpg','nithya_204918_12167533.jpg','vr7'),('clm','Cr.png','clm_Cr.png','cr7'),('suresh','images (2).jpg','suresh_images (2).jpg','efgdsg'),('suresh','suresh_suresh_images (1).jpg','suresh_suresh_suresh_images (1).jpg','ygyuguyas'),('suresh','61I+uMjiuLL._SY355_.jpg','suresh_61I+uMjiuLL._SY355_.jpg','dssdssd'),('suresh','suresh_proimages (2).jpg','suresh_suresh_proimages (2).jpg','fdfdf'),('suresh','cecil-AP463227356214-1000x400.jpg','suresh_cecil-AP463227356214-1000x400.jpg','hallo'),('suresh','suresh_cecil-AP463227356214-1000x400.jpg','suresh_suresh_cecil-AP463227356214-1000x400.jpg','dsdasdsds'),('suresh','suresh_cecil-AP463227356214-1000x400.jpg','suresh_suresh_cecil-AP463227356214-1000x400.jpg','sdssdsfsff'),('suresh','suresh_cecil-AP463227356214-1000x400.jpg','suresh_suresh_cecil-AP463227356214-1000x400.jpg','sdssdsfsff'),('suresh','suresh_cecil-AP463227356214-1000x400.jpg','suresh_suresh_cecil-AP463227356214-1000x400.jpg','sdssdsfsff'),('suresh','images.jpg','suresh_images.jpg','hiuhuihuisd'),('suresh','suresh_images.jpg','suresh_suresh_images.jpg','uiiguguiids'),('suresh','ss.jpg','suresh_ss.jpg','hai'),('suresh','suresh_ss.jpg','suresh_suresh_ss.jpg','hoiggiugu'),('suresh','ss.jpg','suresh_ss.jpg','pug'),('suresh','guide.jpg','suresh_guide.jpg',''),('sudhan','ss.jpg','sudhan_ss.jpg','pug');

UNLOCK TABLES;

/*Table structure for table `profileimages` */

DROP TABLE IF EXISTS `profileimages`;

CREATE TABLE `profileimages` (
  `Fileid` varchar(303) DEFAULT NULL,
  `Filename` varchar(403) DEFAULT NULL,
  `Storedname` varchar(453) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `profileimages` */

LOCK TABLES `profileimages` WRITE;

insert  into `profileimages`(`Fileid`,`Filename`,`Storedname`) values ('clm','Cr.png','clm_proCr.png'),('kahi','bbBlue-eyes-baby-sweety-babies-8885647-1920-1440.jpg','kahi_probbBlue-eyes-baby-sweety-babies-8885647-1920-1440.jpg'),('ramesh','guide.jpg','ramesh_proguide.jpg'),('suresh','sudhan_procecil-AP463227356214-1000x400.jpg','suresh_prosudhan_procecil-AP463227356214-1000x400.jpg'),('raja','',''),('sudhan','cecil-AP463227356214-1000x400.jpg','sudhan_procecil-AP463227356214-1000x400.jpg');

UNLOCK TABLES;

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `mail` varchar(202) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `SecurityQuestion` varchar(300) DEFAULT NULL,
  `Answer` varchar(303) DEFAULT NULL,
  `Macaddress` varchar(305) DEFAULT NULL,
  `Permit` varchar(200) DEFAULT NULL,
  `otp` varchar(33) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `register` */

LOCK TABLES `register` WRITE;

insert  into `register`(`username`,`password`,`dob`,`gender`,`mail`,`phone`,`SecurityQuestion`,`Answer`,`Macaddress`,`Permit`,`otp`) values ('Mahi','123','2016-10-20','Male','jhg2@jhjh.dsd','1234567890','What is your favorite team?','fff',NULL,'Allow',NULL),('Kumar','222','2016-10-02','Male','knsdssn@kk.dd','1234567890','What is your favorite team?','fffff','60-E3-27-14-27-2A','Allow',NULL),('nithya','suresh','2016-11-16','Female','suresh.jayaram07@gmail.com','1234567890','What is your petâ??s name?','wolfyyyy','B8-EE-65-D4-81-C4','Allow','56375095'),('clm','maxi','2016-11-02','Female','kahilanmuthu5@gmail.com','1234567890','RetuWhat is the name of your favorite childhood friend?rned','kahi','B8-EE-65-D4-81-C4','Allow','80269679'),('kahi','lan','2016-11-17','Male','kahilanmuthu5@gmail.com','1234567890','What is your petâ??s name?','khai','B8-EE-65-D4-81-C4','Allow',NULL),('MNBM','JJKG','2016-12-30','Male','SURESH.JAYARAM07@GMAIL.COM','1234567890','RetuWhat is the name of your favorite childhood friend?rned','JHGFHJ','30-52-CB-6A-F7-9D','Allow','SURESH'),('ramesh','123','2016-01-31','Male','SURESH.JAYARAM07@GMAIL.COM','9721548562','What is your petâ??s name?','lion','30-52-CB-6A-F7-9D','Allow','54397129'),('suresh','123','2017-02-03','Male','suresh.stigmata07@gmail.com','9721548562','What was the name of your elementary / primary school?','niuhgbfvdcsa','30-52-CB-6A-F7-9D','Allow','91628806'),('raja','12345','2017-03-04','Male','selvasusmi96@gmail.com','1234567890','What is your petâ??s name?','busgubsy','30-52-CB-6A-F7-9D','Allow','SURESH'),('sudhan','9566043700','1992-06-22','Male','sudhancse2@gmail.com','9566043700','What is your petâ??s name?','sudhan','30-52-CB-6A-F7-9D','Allow','SURESH');

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
